<?php

namespace pocketmine\block;

use pocketmine\item\Item;
use pocketmine\block\Flowable;

class PowerRails extends Flowable{

    protected $id = 27;

    public function __construct($meta = 0){
        $this->meta = $meta;
    }

    public function getName(){
        return "Power Rail";
    }

    public function getHardness(){
        return 0.6;
    }

    public function canPassThrough(){
        return true;
    }
	
	public function onBreak(Item $item){
		$this->getLevel()->setBlock($this, new Air(), true);

		return true;
	}

	public function getDrops(Item $item){
		return [];
	}

}